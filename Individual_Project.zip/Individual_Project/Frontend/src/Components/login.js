import React from "react";
import { useState } from 'react';
import './login.css'

function Login(){
    const [empid, setEmpid] = useState('');
    const [password, setPassword] = useState('');
    const [loginMessage, setLoginMessage] = useState('');
  
    const handleLogin = () => {
      // Send login data to server using fetch
      fetch('http://localhost:8080/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ empid, password })
      })
        .then(response => response.json())
        .then(data => {
          setLoginMessage(data.message);
        })
        .catch(error => {
          console.error(error);
        });
    };
    return(
        <div>
                
        <div className="wrapperr">
            <h2>Login</h2>
            <form className="form-wrap">
                <label>Empid</label>
                <input
                 type="text"
                  className="username"
                   placeholder="Username"
                   value={empid}
                   onChange={(e) => setEmpid(e.target.value)}                   
                   required />
                <label>Password</label>
                <input
                 type="text"
                  className="password"
                   placeholder="password"
                   value={password}
                   onChange={(e) => setPassword(e.target.value)} 
                   required />
                <button onClick={handleLogin}  className="btn-log">Submit</button>
                {loginMessage && <p>{loginMessage}</p>}
                <p>Don't have an account <a href="signin">Signin</a> </p>
            </form>
        </div>
        </div>
    )
}

export default Login;