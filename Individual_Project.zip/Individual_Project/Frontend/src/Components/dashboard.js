import React from "react";
import "./dashboard.css"


function Dashboard(){
    return(
        <>
            <div class="wrapper">
            <div class="sidebar">
                <div class="logo">
                    <img src="jin"
                        alt="Jin" class="image-class"/>
                </div>
                <ul class="list">
                    <li class="menu"><a href="#">Dashboard</a></li>
                    <li class="menu"><a href="#">Timesheet</a></li>
                    <li class="menu"><a href="#">Leave</a></li>
                    <li class="menu"><a href="#">Work From Home</a></li>
                    <button class="dropdownlist">Approvals<i class="fa fa-chevron-down"></i></button>
                    <div class="dropdownlist_container">
                        <li class="d_menu"><a href="#">Leave Approval</a></li>
                        <li class="d_menu"><a href="#">Allocation Extension
                                Approval</a></li>
                        <li class="d_menu"><a href="#">Timesheet Approval</a></li>
                        <li class="d_menu"><a href="#">Permission Approval</a></li>
                        <li class="d_menu"><a href="#">WFH Approval</a></li>
                        <li class="d_menu"><a href="#">KRA Review</a></li>
                        <li class="d_menu"><a href="#">Comp Off Approval</a></li>
                        <li class="d_menu"><a href="#">Expense Approval</a></li>
                    </div>
                    



                    <li class="menu"><a href="#">Survey</a></li>
                    <li class="menu"><a href="#">Service Desk</a></li>
                    <li class="menu"><a href="#">Forms</a></li>
                </ul>

                <div class="footer">
                    <div class="thin-line"></div>
                    <a href="#" class="logout">Vivek V <i
                            class="fa-solid fa-arrow-right-from-bracket"></i></a>
                </div>
            </div>
        </div>

        
        </>
    )
}

export default Dashboard;