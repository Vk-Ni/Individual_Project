const express = require('express')
const sql = require('mysql2');
const doenv = require("dotenv");
const cors = require('cors')
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');

const app = express();
const port = 8080;

app.use(bodyParser.json());

doenv.config({
    path:'./.env'
})

app.use(cors())
app.use(express.json())

const db = sql.createConnection({
    host: process.env.DATABASE_HOST,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASS,
    database: process.env.DATABASE,
});


db.connect((err)=>{
    if(err){
        console.log(err);
    }else{
        console.log("mysql success");
    }
});


app.post('/register', (req, res) => {
  const { emp_id,name,email_id, phone_number,designation, password } = req.body;

  // Hash password
  bcrypt.hash(password, 10, (err, hash) => {
    if (err) throw err;

    const newUser = {
      
      emp_id,
      name,
      email_id,
      phone_number,      
      designation,
      
      password: hash
    };

    
    db.query('INSERT INTO user_details (emp_id,name,email_id,phone_number,designation,password) VALUES (?)', newUser, (err) => {
      if (err) throw err;
      res.status(201).json({ message: 'User registered successfully' });
    });
  });
});



const secretKey = 'your_secret_key';

app.post('/login', (req, res) => {
  const { empid, password } = req.body;

  db.query('SELECT * FROM users WHERE empid = ?', [empid], (err, results) => {
    if (err) throw err;

    if (results.length === 0) {
      return res.status(401).json({ message: 'Invalid empid or password' });
    }

    const user = results[0];
    bcrypt.compare(password, user.password, (err, isMatch) => {
      if (err) throw err;

      if (isMatch) {
        // Create and return a JWT token
        const token = jwt.sign({ empid: user.empid }, secretKey);
        res.json({ message: 'Login successful', token });
      } else {
        res.status(401).json({ message: 'Invalid empid or password' });
      }
    });
  });
});

app.get('/profile', (req, res) => {
  const token = req.headers.authorization?.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Unauthorized' });
  }

  try {
    const decoded = jwt.verify(token, secretKey);
    const empid = decoded.empid;

    db.query('SELECT empid, name, email, phone FROM users WHERE empid = ?', [empid], (err, results) => {
      if (err) throw err;

      if (results.length === 0) {
        return res.status(404).json({ message: 'User not found' });
      }

      const user = results[0];
      res.json(user);
    });
  } catch (error) {
    res.status(401).json({ message: 'Unauthorized' });
  }
});




app.get('/api/data', (req, res) => {
    const query = 'SELECT project_name,start_date,end_date,project_description,team_lead FROM project_allocation';
    db.query(query, (err, results) => {
      if (err) {
        res.status(500).json({ error: 'Error fetching data from database' });
      } else {
        res.status(200).json(results);
      }
    });
  });

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
  });