import React, { useState, useEffect } from 'react';

function Profile({ token }) {
  const [userProfile, setUserProfile] = useState(null);

  useEffect(() => {
    // Fetch user profile data using the token
    fetch('http://localhost:8080/login/profile', {
      headers: {
        Authorization: `Bearer ${token}`
      }
    })
      .then(response => response.json())
      .then(data => {
        setUserProfile(data);
      })
      .catch(error => {
        console.error(error);
      });
  }, [token]);

  return (
    <div>
      <h2>User Profile</h2>
      {userProfile ? (
        <>
          <p>Employee ID: {userProfile.empid}</p>
          <p>Name: {userProfile.name}</p>
          <p>Email: {userProfile.email}</p>
          <p>Phone: {userProfile.phone}</p>
        </>
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
}

export default Profile;
