import { useState } from 'react';
import React from "react";
import './signin.css';

function Signin(){

    const [name, setUsername] = useState('');
    const [emp_id, setEmpid] = useState('');
    const [email_id, setEmail] = useState('');
    const [phone_number, setPhoneNumber] = useState('');
    const [designation, setDesignation] = useState('');    
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    // const [errorMessage, setErrorMessage] = useState(''); 

    const [passwordMatchError, setPasswordMatchError] = useState('');
  const [emailFormatError, setEmailFormatError] = useState('');
  const [registrationMessage, setRegistrationMessage] = useState('');


  const handleRegister = () => {
    // Validate email format
    if (!/\S+@\S+\.\S+/.test(email_id)) {
      setEmailFormatError('Invalid email format');
      return;
    }
    setEmailFormatError('');

    // Validate password and confirm password match
    if (password !== confirmPassword) {
      setPasswordMatchError('Passwords do not match');
      return;
    }
    setPasswordMatchError('');

    fetch('http://localhost:8080/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ emp_id,name,email_id, phone_number,designation, password })
      })
        .then(response => response.json())
        .then(data => {
          setRegistrationMessage(data.message);
        })
        .catch(error => {
          console.error(error);
        });
    };


    return(
        <>
        <div className="wrap">
            <h2>Sign In</h2>
            <form className="formwrap">
                <label>Username</label>
                <input type="text" placeholder="Username" value={name} onChange={(e) => setUsername(e.target.value)}    required />
                <label>Employee Code</label>
                <input type="text" placeholder="Employee Code" value={emp_id} onChange={(e) => setEmpid(e.target.value)}   required />
                <label>Designation</label>
                <input type="text" placeholder="Designation"value={designation} onChange={(e) => setDesignation(e.target.value)} required />
                <label>Email</label>
                <input type="text" placeholder="Email" value={email_id} onChange={(e) => setEmail(e.target.value)}   required />
                {emailFormatError && <p style={{ color: 'red' }}>{emailFormatError}</p>}
                <label>Phone Number</label>
                <input type="text" placeholder="Phone Number" value={phone_number} onChange={(e) => setPhoneNumber(e.target.value)}   required />
                <label>Password</label>
                <input type="text" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)}   required />
                <label>Confirm Password</label>
                <input type="text" placeholder="Confirm Password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)}   required />
                {passwordMatchError && <p style={{ color: 'red' }}>{passwordMatchError}</p>}

                <button onClick={handleRegister} className="btn-signin">Submit</button>
                {registrationMessage && <p>{registrationMessage}</p>}
                <p>Don't have an account <a href="/">Login</a> </p>
            </form>
        </div>
        </>
    );
}

export default Signin;