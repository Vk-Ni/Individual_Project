import React, { useState } from 'react';
import Profile from './profile';
import Login from './login';


function Tok() {
  const [token, setToken] = useState('');

  const handleLogin = (newToken) => {
    setToken(newToken);
  };

  return (
    <div>
      {token ? (
        <Profile token={token} />
      ) : (
        <Login onLogin={handleLogin} />
      )}
    </div>
  );
}

export default Tok;
